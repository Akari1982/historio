Data.Unit = {}



Data.Unit[ "Player" ] =
{
    health = 100,
    material = { { "Flesh" }, },

    -- RPG
    intellect = 0, -- this required to learn new tech and use items
    level = 1, -- each level increase stats
    expirience = 0, -- growth over time for next level
}
