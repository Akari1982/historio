Data.Terrain = {}



Data.Terrain[ "Ground" ] =
{
    passable = true,
}

Data.Terrain[ "Water" ] =
{
    passable = false,
}
