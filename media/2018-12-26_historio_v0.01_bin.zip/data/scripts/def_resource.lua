Data.Resource = {}



Data.Resource[ "Stone" ] =
{
    gather_item = "Stone",
    gather_amount = 1,
    require_tool = false,
}

Data.Resource[ "Branch" ] =
{
    gather_item = "Wood",
    gather_amount = 1,
    require_tool = false,
}
