#include <OgreStringConverter.h>

#include "CameraManager.h"
#include "ConfigCmdManager.h"
#include "Console.h"



void
CameraManager::InitCommands()
{
}
