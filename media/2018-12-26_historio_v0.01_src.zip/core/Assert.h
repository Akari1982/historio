#ifndef ASSERT_H
#define ASSERT_H

#include <cassert>



#define QGEARS_ASSERT( exp, text ) assert( exp && text )



#endif // ASSERT_H
