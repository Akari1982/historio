#ifndef CONFIG_FILE_H
#define CONFIG_FILE_H

#include <OgreString.h>



class ConfigFile
{
public:
    void            Execute(const Ogre::String& name);
};



#endif // CONFIG_FILE_H
