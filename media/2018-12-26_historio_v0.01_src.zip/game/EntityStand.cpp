#include "EntityStand.h"



EntityStand::EntityStand( Ogre::SceneNode* node ):
    Entity( node )
{
}



EntityStand::~EntityStand()
{
}
