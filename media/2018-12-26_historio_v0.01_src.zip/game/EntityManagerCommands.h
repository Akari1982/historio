#include "../core/Console.h"
#include "../core/ConfigCmdManager.h"
#include "../core/ConfigVarManager.h"
#include "EntityManager.h"

#include <OgreStringConverter.h>



void
EntityManager::InitCmd()
{
}
