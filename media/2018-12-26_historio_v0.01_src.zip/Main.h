#ifndef MAIN_H
#define MAIN_H



enum QG_STATE
{
    QG_EXIT,
    QG_GAME
};



extern QG_STATE g_ApplicationState;



#define QG_VERSION_NAME "Historio v0.01"



#endif // MAIN_H
